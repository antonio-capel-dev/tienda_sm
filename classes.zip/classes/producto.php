-<?php
// Cargar la definición de la clase Producto una sola vez
require_once __DIR__ . '/producto.class.php';

// Si quieres instanciar, pasa los parámetros requeridos por el constructor.
// Por ejemplo: $objProducto = new Producto($id, $nombre, $descripcion, $imagen, $precio, $tipo, $impuesto);

?>